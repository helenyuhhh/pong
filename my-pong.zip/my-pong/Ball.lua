Ball = Class{}
-- initialize the ball value
function Ball:init(x,y,width, height)
    self.x = x -- self is simliar with 'this' in c# or java
    self.y = y
    self.width = width
    self.height = height
    self.dx = math.random(-50, 50)
    self.dy = math.random(2)==1 and -100 or 100 -- similar with math.random(2) == 1?-100 or 100
    
    
end
-- reset the ball to its initial position, with initial x and y (position)
function Ball:reset() 
    self.x = VIRTUAL_WIDTH/2 - 4
    self.y = VIRTUAL_HEIGHT/2 - 4
    self.dx = math.random(-50, 50)
    self.dy = math.random(2)==1 and -100 or 100 -- similar with math.random(2) == 1?-100 or 100
    
end
-- updating the dx and dy, changes its position not the actual size -_-|||
function Ball:update(dt) 
    -- continuously called for updated ball position
    self.x = self.x + dt * self.dx
    self.y = self.y + dt * self.dy
end
--render the ball
function Ball:render()
    love.graphics.rectangle('fill', self.x , self.y, self.width, self.height)
end

function Ball:collides(paddle)
    if self.x + self.width < paddle.x or self.x > paddle.x + paddle.width then
        return false
    end
    if self.y + self.height < paddle.y or self.y > paddle.y + paddle.height then
        return false
    end
    return true
end


