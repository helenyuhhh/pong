
-- introducing the library
push = require 'push'
Class = require 'class'
-- introducing the classes
require 'Ball'
require 'Paddle'
--1. Define window size: 1280*720
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
-- local table
VIRTUAL_WIDTH = 432
VIRTUAL_HEIGHT = 243
PADDLE_SPEED = 200

function love.load() -- initialize our game state at the beginning, will be called exactly once when the game starts
    -- generate ga,e window with exact size
    love.graphics.setDefaultFilter('nearest', 'nearest')
    love.window.setTitle('Pong') 
    myFont = love.graphics.newFont('font.ttf', 8)
    largeFont = love.graphics.newFont('font.ttf', 16)
    scoreFont = love.graphics.newFont('font.ttf', 32)
    sounds = {
        -- difference between static and stream:
        --static: allocate memory for sound file
        --stream: suitbale for large games who has extra memory to store the sound files
        ['hit_paddle'] = love.audio.newSource('sounds/hit_paddle.wav', 'static'),
        ['score'] = love.audio.newSource('sounds/score.wav', 'static'),
        ['wall_hit'] = love.audio.newSource('sounds/wall_hit.wav', 'static'),
        ['win'] = love.audio.newSource('sounds/wall_hit.wav', 'static')
    }
    math.randomseed(os.time()) -- make sure that the seed is alwauys different
    push:setupScreen(VIRTUAL_WIDTH, VIRTUAL_HEIGHT,WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = false,
        resizable = true,
        vsync = true
    })

    player1Score = 0
    player2Score = 0
-----------------------------------------------------------------------------
    whoServes = 1 -- initially player1 serves when the game starts 
    whoWins = 0
-- initiate the left paddle, right paddle and the ball------------------
    player1 = Paddle(10, 30, 5, 20)  
    player2 = Paddle(VIRTUAL_WIDTH-10, VIRTUAL_HEIGHT-30, 5, 20)
    ball = Ball(VIRTUAL_WIDTH/2-4, VIRTUAL_HEIGHT/2-4, 4, 4)
    gameState = 'start'
end

function love.resize(w, h) --resize the game including the UI
    push:resize(w, h)
end
-- called repeatly by the passing time
-- using the new method
function love.update(dt)
    -- chack the game status
    if gameState == 'serve' then -- ball launch
        ball.dy = math.random(-50, 50)
        if whoServes == 1 then -- player1 serves
            ball.dx = math.random(140, 200)
        else -- player2 serves
            ball.dx = -math.random(140, 200)
        end
    --condition of 'serve' and 'play': getting score
    elseif gameState == 'play' then
        if ball:collides(player1) then -- player1 catches the ball, ball bounce back
            ball.dx = -ball.dx * 1.03
            ball.x = player1.x + 5
            sounds['hit_paddle']:play()
        end
        if ball:collides(player2) then -- player2 catches the ball, ball bounce back
            ball.dx = -ball.dx * 1.03
            ball.x = player2.x - 4
            sounds['hit_paddle']:play()
        end
        if ball.dy < 0 then -- ball moves upwards, continue move upwards
            ball.dy = -math.random(10, 150)
        else
            ball.dy = math.random(10, 150)
        end
        ----------------------upper bound and lower bound collision--------------------------
        if ball.y <= 0 then -- reached upper bound
            ball.y = 0
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        elseif ball.y >= VIRTUAL_HEIGHT-4 then
            ball.y = VIRTUAL_HEIGHT -4
            ball.dy = -ball.dy
            sounds['wall_hit']:play()
        end
        if ball.x < 0 then -- player1 lose, player2 win 1 score
            -- press enter to reset the ball. by changing the game state
            whoServes = 1
            player2Score = player2Score + 1
            --sounds['score']:play()
            if player2Score == 10 then -- if reaches to 10, player wins
                sounds['win']:play()
                whoWins = 2
                gameState = 'done'
                
            else
                sounds['score']:play()
                gameState = 'serve'
                ball:reset()
            end
            
        end
        if ball.x > VIRTUAL_WIDTH then -- player2 lose, player1 win 1 score
            -- player2 serves
            whoServes = 2
            player1Score = player1Score + 1
            --sounds['score']:play()
            if player1Score == 10 then -- if reaches to 10, player wins
                sounds['win']:play()
                whoWins = 1
                gameState = 'done'
                
            else
                sounds['score']:play()
                gameState = 'serve'
                ball:reset()
            end
            
        end
    end
    ----------------------detect who serves----------------------------------------------
    
    
    
    -- left paddle movement
    if love.keyboard.isDown('w') then -- left paddle moves up
        player1.dy = -PADDLE_SPEED
    elseif love.keyboard.isDown('s') then
        player1.dy = PADDLE_SPEED
    else 
        player1.dy = 0 --otherwise, the paddle doesn't move
    end
    --right paddle movement
    if love.keyboard.isDown('up') then -- right paddle moves up
        player2.dy = -PADDLE_SPEED
    elseif love.keyboard.isDown('down') then
        player2.dy = PADDLE_SPEED
    else
        player2.dy = 0 -- stop the paddle keep moving
    end
    ------------------------------ball collision_virtical_boundries----------------------
    
    if gameState == 'play' then
        ball:update(dt)
    end
    ----------------------------update the player location--------------------------------
    player1:update(dt)
    player2:update(dt)
    ------------------------------ball collision_player-------------------------
    
end


function love.keypressed(key)
    --down= love.keyboard.isDown(escape) this returns a boolean
    if key == 'escape' then
        love.event.quit()
    
    elseif key == 'enter' or key == 'return' then
        if gameState == 'start' then
            gameState = 'serve'
        elseif gameState == 'serve' then
            gameState = 'play'
        elseif gameState == 'done' then -- since it need to wait for user input, so write here
            gameState = 'serve'
            ball:reset()
            player1Score = 0;
            player2Score = 0;
            if whoWins == 1 then
                whoServes = 2
            else
                whoServes = 1   
            end         
        end
       
    end
end

function love.draw()
    push:apply('start') -- begin rendering at virtal resolution
    love.graphics.clear(40/255, 45/255, 52/255, 255/255)
    love.graphics.setFont(myFont)
    if gameState == 'start' then 
        love.graphics.printf('Hello My-Pong start!', 0, 10, VIRTUAL_WIDTH,'center') -- sring format
        love.graphics.printf('Press Enter To Start', 0, 20, VIRTUAL_WIDTH,'center') -- sring format
    elseif gameState == 'serve' then
        love.graphics.printf('Player '..tostring(whoServes)..' serve', 0, 10, VIRTUAL_WIDTH,'center') -- sring format
        love.graphics.printf('Press Enter To Serve', 0, 20, VIRTUAL_WIDTH,'center') -- string format
    elseif gameState == 'play' then
        --love.graphics.printf('Game in progress!', 0, 20, VIRTUAL_WIDTH,'center') -- string format
    elseif gameState == 'done' then
        love.graphics.setFont(largeFont)
        love.graphics.printf('Player '..tostring(whoWins)..' wins!', 0, 10, VIRTUAL_WIDTH,'center') -- sring format
        love.graphics.setFont(myFont)
        love.graphics.printf('Press Enter To retart', 0, 30, VIRTUAL_WIDTH,'center') -- sring format
    end
    love.graphics.setFont(scoreFont)
    love.graphics.print(tostring(player1Score), VIRTUAL_WIDTH / 2 - 50, 
    VIRTUAL_HEIGHT / 3)
    love.graphics.print(tostring(player2Score), VIRTUAL_WIDTH / 2 + 30, 
    VIRTUAL_HEIGHT / 3)
    -- left paddle
    player1:render()
    -- right paddle
    player2:render()
    -- ball
    ball:render()
    setFPS()
    push:apply('end') -- stop rendering
end
function setFPS()
    love.graphics.setFont(myFont)
    love.graphics.setColor(255/225, 255/225, 51/225)
    love.graphics.print('FPS: ' .. tostring(love.timer.getFPS()), 5, 10)

end    



