Paddle = Class{}
-- initialize the paddle position with given x, y and its size
function Paddle:init(x, y, width, height) 
    self.x = x -- self is simliar with 'this' in c# or java
    self.y = y
    self.width = width
    self.height = height
    self.dy = 0 -- since paddles only up and down, can be considered as speed
end
-- update the paddle location by dt
function Paddle:update(dt) 
    -- if the w or up is down, move upwards (-speed * dt)
    if self.dy < 0 then
        self.y = math.max(self.y + self.dy * dt, 0)
    else
        self.y = math.min(VIRTUAL_HEIGHT - self.height, self.y + self.dy * dt)
    end
end

-- start to rander the paddle
function Paddle:render()
    love.graphics.rectangle('fill', self.x, self.y, self.width, self.height)
end