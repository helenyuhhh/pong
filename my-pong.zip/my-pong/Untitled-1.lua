
function love.update(dt)
    --left paddle
   if love.keyboard.isDown('w') then -- prevent moving upwards and out of bound, must be >=0
        player1.dy = -PADDLE_SPEED
   elseif love.keyboard.isDown('s') then
        player1.dy = PADDLE_SPEED
   else
        player1.dy = 0 -- doesn't move  
   end
   -- right paddle:
   if love.keyboard.isDown('up') then
    player2.dy = -PADDLE_SPEED
   elseif love.keyboard.isDown('down') then
    player2.dy = PADDLE_SPEED
   else  
    player2.dy = 0
   end
   if gameState == 'serve' then
    ball.dy = math.random(-50, 50)
    if whoServes == 1 then-- player serve, set the x velocity
        ball.dx = math.random(140, 200)
    else
        ball.dx = -math.random(140, 200)
   end


   -- now the moving ball
   if gameState == 'play' then
    -- if ball colldies with player1(left paddle)
      if ball:collide(player1) then
         ball.dx = -ball.dx * 1.03 -- dx is our x velocity, also speeding up the game a little bit
         ball.x = player1.x+5 -- +5 means the width of paddle
          if ball.dy < 0 then -- if the ball moves upwards, to reflect, y should continue be negative, moce upwards
            dy = -math.random(10, 150)
          else
            dy = math.random(10, 150)
          end
      end

      if ball:collide(player2) then -- if ball collides with right paddle
         ball.dx = -ball.dx * 1.03
         ball.x = player2.x - 4 -- because the coordinate is based on top left corner, so -4, the width of ball
          if ball.dy < 0 then -- if the ball moves upwards, to reflect, y should continue be negative, moce upwards
             dy = -math.random(10, 150)
          else
             dy = math.random(10, 150)
          end 
      end
     -- noe detect the uppder bpundry and the lower boundry of the ball
      if ball.y <= 0 then -- reach the uppder bound
         ball.y = 0
         ball.dy = -ball.dy
      end
      if ball.y >= VIRTUAL_HEIGHT - 4 then -- reach the uppder bound
         ball.y = VIRTUAL_HEIGHT - 4
         ball.dy = -ball.dy
      end
    


     ball:update(dt)
     player1:update(dt)
     player2:update(dt)
  end
end